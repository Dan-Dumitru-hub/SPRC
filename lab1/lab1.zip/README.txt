ex1
b'{"status":"ok","proof":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ3aG8iOnsibnVtZSI6WyJUaXBhIERhbi1EdW1pdHJ1Il0sImdydXBhIjpbIjM0M0MzIl19LCJkaWQiOiJ0YXNrMSJ9.OhvGFwfv5azYwJdH4EbMMrcV3TPAzdi3naEICUGOP4o"}'

ex2
b'{"status":"ok","proof":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ3aG8iOnsibnVtZSI6IlRpcGEgRGFuLUR1bWl0cnUifSwiZGlkIjoidGFzazIifQ.3X_flfj-bmGhRjUEsZLCu7yC_wyIzk4kzQYPu6DBLhk"}'

ex3
Login succesful! You will be recognised as Tipa Dan-Dumitru for 10 sec.
{"status":"ok","proof":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ3aG8iOnsibnVtZSI6IlRpcGEgRGFuLUR1bWl0cnUifSwiZGlkIjoidGFzazMifQ.z2SnjJiABGrzNYdvMkbdK1qRTLDDklRZNIDXkKbMSDw"}
