Tipa Dan-Dumitru
gr 343C3

Am facut aproape toate requesturile pt server mai putin GET pt Temperatures.
Am pornit de la codul scris in laboratorul 3.

Pentru Countries nu a trebuit sa modific mult fata de codul original inafara de return unde a trebui sa adaug si id-ul tarii precum si codul 201

Pentru Cities am facut similar cu Countries doar ca acum trebuie sa verific la PUT si la POST daca id-ul tarii se afla in baza de date.

Similar ca la Cities am facut si la Temperatures ,am pornit de la codul de la laborator si a trebuit sa verific la PUT si POST daca id-ul orasului se afla in baza de date.